#!/bin/sh

#tar -xzf linuxcan_BETA.tar.gz
cd linuxcan/
sudo make
sudo make install

#copy libraries to kvaser_canlib package...
LIBNAME=libcanlib.so
LIBRARY=$LIBNAME.1.1.0
SONAME=$LIBNAME.1

cd ..
rm -rf lib/
rm -f lib/$LIBNAME
rm -f lib/$SONAME
mkdir lib/
install  -m 755 linuxcan/canlib/$LIBRARY lib/
cd lib/
ln -s ../linuxcan/canlib/$LIBRARY $LIBNAME
ln -s ../linuxcan/canlib/$LIBRARY $SONAME

cd ..

sudo /sbin/ldconfig
install -m 644 linuxcan/include/canlib.h include/kvaser_canlib
install -m 644 linuxcan/include/canstat.h include/kvaser_canlib

mkdir -p doc/canlib
cp -r linuxcan/doc/HTMLhelp doc/canlib

# Examples
cp -r linuxcan/canlib/examples doc/canlib